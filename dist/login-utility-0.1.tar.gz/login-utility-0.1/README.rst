=====
login-utility
=====

login-utility is a simple Django app to make login and forget password

Detailed documentation is in the "docs" directory.
